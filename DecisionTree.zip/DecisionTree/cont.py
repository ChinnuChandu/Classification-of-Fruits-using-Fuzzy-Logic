

import csv
import cv2
import numpy as np
import glob
import os , math

#check the file size to add the header to the csv
if os.path.getsize("fruitsTrain.csv")==0:

    with open('fruitsTrain.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["SN", "Name", "Area", "Perimiter","R","G","B","Roundness"])

FruitName="ORANGE"  #Rename this to the fruit name of which u need to extract the feature

i=1317  #the index(SN) in the csv file , used to continue the index with the value of last index record
for image in os.listdir('dataset/Orange/train/'):
    i=i+1
    img = cv2.imread(os.path.join('dataset/Orange/train/', image))
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

    _, thresh = cv2.threshold(gray, 245, 255, cv2.THRESH_BINARY_INV)

    contours,hierarchy = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    #to find large contour
    areas= [cv2.contourArea(c) for c in contours]
    max_index=np.argmax(areas)
    cnt=contours[max_index]
    x,y,w,h=cv2.boundingRect(cnt)
    cv2.rectangle(img,(x,y),(x+w,y+h),(0.255,0),2)

    final = cv2.drawContours(img,contours, -1, (0,255,0), 3)

    #print("Area = ",cv2.contourArea(cnt))
    Area = cv2.contourArea(cnt)

    #print("Perimiter = ",cv2.arcLength(cnt,True))
    Perimiter = cv2.arcLength(cnt,True)
    p1=f"{Perimiter:.2f}"
    fPeri=float(p1)

    #Mean RGB
    avg_color_per_row = np.average(img, axis=0)
    avg_color = np.average(avg_color_per_row, axis=0)
    #----print(avg_color)
    [B,G,R]=avg_color #separate rgb values to each variable
    r1=f"{R:.2f}"
    fR=float(r1)                    #-----print(B,G,R)
    g1=f"{G:.2f}"
    fG=float(g1)
    b1=f"{B:.2f}"
    fB=float(b1)


    #shape/roundness of the fruit
    shape=4*math.pi*(Area/(fPeri*fPeri))  #print(shape)
    s1=f"{shape:.2f}"
    fShape=float(s1)

    with open('fruitsTrain.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([i, FruitName, Area, fPeri,fR ,fG ,fB, fShape])

    #cv2.imshow("contour",final)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()
print(FruitName,"FRUIT FEATURE EXTRACTION SUCCESSFULL")