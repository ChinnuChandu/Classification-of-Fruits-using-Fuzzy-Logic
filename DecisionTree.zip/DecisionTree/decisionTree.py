import os ,csv
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from IPython.display import Image
from sklearn import tree
import pydotplus

#path = ' C:\\Users\\dhanu\\projects\\DecisionTree\\car_integer_exceptY.csv'
#df = pd.read_csv(path)
script_dir = os.getcwd()
file = 'fruitsTrain.csv'
df = pd.read_csv(os.path.normcase(os.path.join(script_dir, file)))

print(df.head())

X_train = df.loc[:,'Area':'Roundness'] #Gets all the rows in the dataset from column 'buying' to column 'safety'
Y_train = df.loc[:,'Name'] #Gets all of the rows in the dataset from column 'values'

# The actual decision tree classifier
trees = DecisionTreeClassifier(max_leaf_nodes=7, random_state=4)

# Train the model
trees.fit(X_train, Y_train)

#get the column names
feature_names = list(X_train.columns)
#print(feature_names)


dot_data = tree.export_graphviz(trees, out_file=None,feature_names=feature_names,                                class_names=Y_train)

# Draw graph
graph = pydotplus.graph_from_dot_data(dot_data)

# save graph
Image(graph.create_png())
graph.write_png("tree0.png")

# Make your prediction
print('\n\nPrinting the prediction: \n')

with open('fruitsTest.csv', 'r') as read_obj:
    csv_dict_reader = csv.DictReader(read_obj)
    for row in csv_dict_reader:
        #print(row['Area'])
        prediction = trees.predict([[row['Area'],row['Perimiter'],row['R'],row['G'],row['B'],row['Roundness']]])
        print(row['SN'], prediction)

#Print the accuracy
print("\nAccuracy : ",trees.score(X_train,Y_train)*100,"%")

